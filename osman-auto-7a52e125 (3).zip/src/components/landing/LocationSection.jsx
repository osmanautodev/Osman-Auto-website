import React from "react";
import { motion } from "framer-motion";
import { MapPin, Building2, Clock, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Custom car marker icon
const carIcon = L.divIcon({
  html: `<div style="position: relative; width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
    <div style="position: absolute; bottom: 0; width: 8px; height: 8px; background: rgba(239, 68, 68, 0.3); border-radius: 50%; filter: blur(4px);"></div>
    <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter: drop-shadow(0 2px 4px rgba(0,0,0,0.5));">
      <path d="M5 11L6.5 6.5H17.5L19 11M5 11V17.5H6.5M5 11H19M19 11V17.5H17.5M6.5 17.5V19.5M6.5 17.5H17.5M17.5 17.5V19.5M8 14.5C8 15.0523 7.55228 15.5 7 15.5C6.44772 15.5 6 15.0523 6 14.5C6 13.9477 6.44772 13.5 7 13.5C7.55228 13.5 8 13.9477 8 14.5ZM18 14.5C18 15.0523 17.5523 15.5 17 15.5C16.4477 15.5 16 15.0523 16 14.5C16 13.9477 16.4477 13.5 17 13.5C17.5523 13.5 18 13.9477 18 14.5Z" 
      stroke="#DC2626" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="#EF4444"/>
    </svg>
  </div>`,
  className: 'custom-car-marker',
  iconSize: [50, 50],
  iconAnchor: [25, 50],
  popupAnchor: [0, -50]
});

export default function LocationSection() {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-24 md:py-32 bg-[#0A0A0A] border-t border-zinc-900 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-white rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left side - Info */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.25, 0.1, 0.25, 1] }}
          >
            <p className="text-zinc-600 tracking-[0.3em] uppercase text-xs mb-6 font-semibold">
              Локация
            </p>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-8 relative">
              <span className="bg-gradient-to-r from-white via-zinc-300 to-zinc-400 bg-clip-text text-transparent">Наш офис</span>
              <div className="absolute -bottom-3 left-0 w-24 h-1 bg-white" />
            </h2>

            <p className="text-xl md:text-2xl bg-gradient-to-r from-zinc-300 to-zinc-400 bg-clip-text text-transparent font-light leading-relaxed mb-12">
              Собственный автосалон в центре столицы
            </p>

            <div className="space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2, duration: 0.6 }}
                className="flex items-start gap-4 group"
              >
                <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 group-hover:border-white flex items-center justify-center flex-shrink-0 transition-colors duration-300">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Адрес</h3>
                  <p className="text-zinc-400 font-light">
                    г. Москва, Ленинградский проспект 36с30
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3, duration: 0.6 }}
                className="flex items-start gap-4 group"
              >
                <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 group-hover:border-white flex items-center justify-center flex-shrink-0 transition-colors duration-300">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Автосалон</h3>
                  <p className="text-zinc-400 font-light">
                    Премиум-локация с полным сервисом
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4, duration: 0.6 }}
                className="flex items-start gap-4 group"
              >
                <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 group-hover:border-white flex items-center justify-center flex-shrink-0 transition-colors duration-300">
                  <Clock className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Режим работы</h3>
                  <p className="text-zinc-400 font-light">
                    Ежедневно, по предварительной записи
                  </p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5, duration: 0.6 }}
                className="flex items-start gap-4 group"
              >
                <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 group-hover:border-white flex items-center justify-center flex-shrink-0 transition-colors duration-300">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold mb-2">Связь</h3>
                  <p className="text-zinc-400 font-light">
                    Telegram, WhatsApp, звонок
                  </p>
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6, duration: 0.6 }}
              className="mt-12"
            >
              <Button
                onClick={scrollToContact}
                className="bg-white text-black hover:bg-zinc-200 px-10 py-6 text-sm font-bold tracking-widest transition-all duration-500 rounded-lg"
              >
                ЗАПИСАТЬСЯ НА ВСТРЕЧУ
              </Button>
            </motion.div>
          </motion.div>

          {/* Right side - Interactive Map */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, delay: 0.2, ease: [0.25, 0.1, 0.25, 1] }}
            className="relative"
          >
            {/* Decorative frame */}
            <div className="absolute -inset-4 border border-zinc-800">
              <div className="absolute -top-2 -left-2 w-8 h-8 border-l-2 border-t-2 border-zinc-600" />
              <div className="absolute -top-2 -right-2 w-8 h-8 border-r-2 border-t-2 border-zinc-600" />
              <div className="absolute -bottom-2 -left-2 w-8 h-8 border-l-2 border-b-2 border-zinc-600" />
              <div className="absolute -bottom-2 -right-2 w-8 h-8 border-r-2 border-b-2 border-zinc-600" />
            </div>

            <div className="aspect-square bg-zinc-900 border border-zinc-800 relative overflow-hidden">
              <div style={{ filter: 'grayscale(100%)', height: '100%', width: '100%' }}>
                <MapContainer 
                  center={[55.7848, 37.5421]} 
                  zoom={16} 
                  style={{ height: '100%', width: '100%' }}
                  scrollWheelZoom={true}
                  dragging={true}
                  zoomControl={true}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <Marker position={[55.7848, 37.5421]} icon={carIcon}>
                    <Popup>
                      <div className="text-center">
                        <strong>OSMAN AUTO</strong><br />
                        Ленинградский проспект 36с30
                      </div>
                    </Popup>
                  </Marker>
                </MapContainer>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}