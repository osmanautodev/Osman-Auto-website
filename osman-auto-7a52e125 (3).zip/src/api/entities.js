import { base44 } from './base44Client';




// auth sdk:
export const User = base44.auth;